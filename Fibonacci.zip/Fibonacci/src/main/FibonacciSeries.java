package main;

import java.util.Scanner;

/**
 * Calculate and print Fibonacci number using recursion Fibonacci number is sum
 * of previous two Fibonacci numbers fn= fn-1+ fn-2 Fibonacci series 
 * example 1, 2, 3, 5, 8, 13, 21, 34, 55
 *
 * @project mastercard
 * @author Vikas
 * @version 1.0
 */
public class FibonacciSeries {

	public static void main(String args[]) {
		int number = getUserInput();

		if (number >= 1) {
			System.out.println("Printing Fibonacci series for " + number + " numbers : ");
			// printing Fibonacci series
			for (int i = 1; i <= number; i++) {
				System.out.print(fibonacci(i) + " ");
			}
			System.out.println("Done...");
		} else {
			System.out.println("Input a number bigger than zero. Exiting!!! ");
		}
	}

	/*
	 * Get User's Input to print prime numbers
	 * 
	 * @return number for fibonacci series
	 */
	public static int getUserInput() {
		// get input to print Fibonacci series
		System.out.println("Enter number for Fibonacci series: ");
		Scanner scanner = new Scanner(System.in);
		int number = scanner.nextInt();
		scanner.close();
		return number;
	}

	/*
	 * Using tail recursion to calculate next Fibonacci number
	 * 
	 * @return Fibonacci number
	 */
	public static int fibonacci(int number) {
		if (number == 1 || number == 2) {
			return 1;
		}
		return fibonacci(number - 1) + fibonacci(number - 2);
	}

}
