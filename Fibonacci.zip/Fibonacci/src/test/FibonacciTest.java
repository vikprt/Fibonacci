package test;

import static org.junit.Assert.*;

import org.junit.Test;

import main.FibonacciSeries;

public class FibonacciTest {

	/*
	 * Test to see the vale of 10th number 
	 */
	@Test
	public void testFibonacciFor10thNumber() {
		int number = FibonacciSeries.fibonacci(10);
		assertEquals("Expected Number should be 55", 55, number);
	}

}
